// Copyright (c) 2026 Jong Bhak. Licensed under BioLicense 1.0; see LICENSE.
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading;
using Microsoft.Win32;

namespace BioPager {
 // Persistent isolated helper: COM and native exports are initialized once.
 // Calls still run outside the pager process; no Explorer injection or elevation.
 internal static class MoveWorker {
  const string ExpectedHash="8740c572a1c000e3b87ffeb1e4c397eae9af3bd4a2abdc3bcffacab4493f8ff5";
  [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
  [DllImport("kernel32.dll",CharSet=CharSet.Ansi,ExactSpelling=true)] static extern IntPtr GetProcAddress(IntPtr module,string name);
  [DllImport("kernel32.dll")] static extern uint SetErrorMode(uint mode);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int Count();
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int SwitchDesktop(int index);
  static IDesktopManager manager;
  static Count count,currentNumber;
  static DesktopId id;
  static WindowQuery pinned,pinnedApp;
  static MoveWindow move;
  static SwitchDesktop changeDesktop;
  static int ready=-1;
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate Guid DesktopId(int index);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int WindowQuery(IntPtr window);
  [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int MoveWindow(IntPtr window,int index);
  static T Export<T>(IntPtr module,string name) where T:class {
   IntPtr address=GetProcAddress(module,name);if(address==IntPtr.Zero)throw new EntryPointNotFoundException(name);
   return Marshal.GetDelegateForFunctionPointer(address,typeof(T)) as T;
  }
  static List<Guid> DesktopIds(){
   List<Guid> ids=new List<Guid>();
   using(RegistryKey k=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\VirtualDesktops")){
    byte[] b=k==null?null:k.GetValue("VirtualDesktopIDs") as byte[];
    if(b!=null&&b.Length%16==0)for(int i=0;i<b.Length;i+=16){byte[] g=new byte[16];Array.Copy(b,i,g,0,16);ids.Add(new Guid(g));}
   }return ids;
  }
  static bool SupportedWindows(){
   using(RegistryKey k=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion")){
    if(k==null)return false;int build,revision;
    if(!Int32.TryParse(Convert.ToString(k.GetValue("CurrentBuildNumber")),out build))return false;
    Int32.TryParse(Convert.ToString(k.GetValue("UBR")),out revision);
    return (build==26100&&revision>=2605)||build==26200;
   }
  }
  internal static int Run(string[] args){
   SetErrorMode(0x0001|0x0002); // Native failures return an exit code, not a modal OS dialog.
   try{
    long raw;uint pid;Guid source,target;
    if(args.Length!=5||!Int64.TryParse(args[1],out raw)||!UInt32.TryParse(args[2],out pid)||!Guid.TryParse(args[3],out source)||!Guid.TryParse(args[4],out target))return 10;
    int init=EnsureReady();if(init!=0)return init;
    IntPtr window=new IntPtr(raw);uint actualPid;
    if(!Native.IsWindow(window))return 11;
    Native.GetWindowThreadProcessId(window,out actualPid);if(actualPid!=pid)return 11;
    Guid actual;if(manager.GetWindowDesktopId(window,out actual)!=0||actual!=source)return 12;
    if(source==target)return 0;
    int pin=pinned(window),appPin=pinnedApp(window);if(pin==1||appPin==1)return 24;if(pin<0||appPin<0)return 23;
    List<Guid> ids=DesktopIds();int from=ids.IndexOf(source),to=ids.IndexOf(target);
    if(from<0||to<0||count()!=ids.Count)return 12;
    // Verify native enumeration agrees with Explorer before moving anything.
    if(id(from)!=source||id(to)!=target)return 12;
    if(!Native.IsWindow(window))return 11;
    Native.GetWindowThreadProcessId(window,out actualPid);if(actualPid!=pid)return 11;
    if(manager.GetWindowDesktopId(window,out actual)!=0||actual!=source)return 12;
    int result=move(window,to);
    for(int n=0;n<30;n++){
     if(manager.GetWindowDesktopId(window,out actual)==0&&actual==target)return 0;
     Thread.Sleep(10);
    }
    return result<0?25:26;
   }catch {return 40;}
  }
  static int EnsureReady(){
   if(ready!=-1)return ready;
   try{
    if(!Environment.Is64BitProcess||!SupportedWindows())return ready=20;
    int code=Initialize();ready=code;return code;
   }catch{return ready=40;}
  }
  static int Initialize(){
    string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"native","VirtualDesktopAccessor.dll");
    if(!File.Exists(path))return 21;
    using(SHA256 hash=SHA256.Create())using(FileStream f=File.OpenRead(path)){
     string digest=BitConverter.ToString(hash.ComputeHash(f)).Replace("-","").ToLowerInvariant();if(digest!=ExpectedHash)return 22;
    }
    IntPtr module=LoadLibraryEx(path,IntPtr.Zero,0x1100);if(module==IntPtr.Zero)return 23;
    count=Export<Count>(module,"GetDesktopCount");
    id=Export<DesktopId>(module,"GetDesktopIdByNumber");
    pinned=Export<WindowQuery>(module,"IsPinnedWindow");pinnedApp=Export<WindowQuery>(module,"IsPinnedApp");
    move=Export<MoveWindow>(module,"MoveWindowToDesktopNumber");
    currentNumber=Export<Count>(module,"GetCurrentDesktopNumber");
    changeDesktop=Export<SwitchDesktop>(module,"GoToDesktopNumber");
    manager=(IDesktopManager)Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("AA509086-5CA9-4C25-8F95-589D3C07B48A")));
    return count()<0?23:0;
  }
  static int Switch(Guid target){
   int init=EnsureReady();if(init!=0)return init;
   List<Guid> ids=DesktopIds();int to=ids.IndexOf(target);
   if(to<0||count()!=ids.Count||id(to)!=target)return 12;
   if(currentNumber()==to)return 0;
   // VDA calls the native SwitchDesktop method, not SwitchDesktopWithAnimation.
   int result=changeDesktop(to);
   for(int n=0;n<30;n++){
    int actual=currentNumber();if(actual>=0&&id(actual)==target)return 0;
    Thread.Sleep(5);
   }
   return result<0?23:26;
  }
  internal static void Serve(){
   SetErrorMode(0x0001|0x0002);
   try{
    using(StreamReader input=new StreamReader(Console.OpenStandardInput(),new System.Text.UTF8Encoding(false)))
    using(StreamWriter output=new StreamWriter(Console.OpenStandardOutput(),new System.Text.UTF8Encoding(false))){
    string line;
    while((line=input.ReadLine())!=null){
     int code=10;
     try{
      string[] args=line.Split(' ');Guid target;
      if(line=="ping")code=EnsureReady();
      else if(args.Length==2&&args[0]=="switch"&&Guid.TryParse(args[1],out target))code=Switch(target);
      else if(args.Length==5&&args[0]=="move")code=Run(args);
     }catch{code=40;}
     output.WriteLine(code);output.Flush();
    }
    }
   }finally{if(manager!=null)Marshal.ReleaseComObject(manager);}
  }
  internal static string Describe(int result){
   switch(result){
    case 11:return "The selected window closed or changed. Try dragging it again.";
    case 12:return "The desktop layout changed. Refresh and drag the window again.";
    case 20:return "Direct switching and app dragging require Windows 11 24H2 (26100.2605+) or 25H2 (26200). Use Win+Tab on this build.";
    case 21:return "The native helper is missing. Extract the entire ZIP, including its native folder.";
    case 22:return "The native helper differs from this release. Extract a fresh copy of the ZIP.";
    case 24:return "This app is shown on all desktops. Turn that option off in Win+Tab before moving it.";
    case 25:return "Windows refused to move this window. It may be protected or elevated. Try Win+Tab.";
    case 26:return "Windows did not confirm the move. Check the app in Win+Tab.";
    case 91:return "The move helper timed out. Check the window in Win+Tab before retrying.";
    default:return "The move could not be confirmed on this Windows build. Use Win+Tab for this window. Code: "+result;
   }
  }
 }
}
