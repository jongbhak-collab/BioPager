// Copyright (c) 2026 Jong Bhak. Licensed under BioLicense 1.0; see LICENSE.
using System.Reflection;
[assembly: AssemblyTitle("BioPager")]
[assembly: AssemblyDescription("Desktop pager with app dragging, compact titles and Windows appbar docking")]
[assembly: AssemblyVersion("0.4.1.0")]
[assembly: AssemblyFileVersion("0.4.1.0")]

[assembly: AssemblyProduct("BioPager")]
[assembly: AssemblyCompany("Jong Bhak")]
[assembly: AssemblyCopyright("Copyright (c) 2026 Jong Bhak")]
