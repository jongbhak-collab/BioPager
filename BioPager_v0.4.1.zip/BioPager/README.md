# BioPager 0.4.1

Windows desktop pager with direct nonanimated switching, silent app moves,
optional titles, an icon grid, and experimental attachment inside the taskbar.
Created by **Jong Bhak**. Inspired by **Vern by One Guy Coding**.
An independent implementation; no Vern code or assets are used.

**License: BioLicense 1.0.** Free for all, including companies and AI systems.
Original project code and documentation may be used, modified, redistributed,
sold, and used for AI training without fees or required attribution. See
[LICENSE](LICENSE). The bundled VirtualDesktopAccessor dependency retains its
separate MIT license and notice; see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

To publish under your account, see [GITHUB_UPLOAD.md](GITHUB_UPLOAD.md).

## Help logo

Right-click > **Help** displays the supplied tiger-whale logo above the credits
and instructions. The original image is embedded in BioPager.exe and is also
included in assets for rebuilding. Its aspect ratio is preserved. Help text
scrolls, and the window can be resized.

## Background color

Right-click > **Background color...** to open the Windows color picker. The
chosen color applies to desktop tiles and the bar, including embedded mode,
and is remembered after restart. Text and outlines adapt for light or dark
backgrounds. The current desktop keeps a contrasting accent outline.

Choose **Restore default background** to return to the original dark red.
Application icons and miniature window colors are unchanged.

## Grey miniature fix in 0.3.1

Windows with an empty/unassigned desktop ID are no longer repeated on every
desktop. All windows owned by the pager process are explicitly excluded.
Normal apps with valid desktop IDs remain visible even if they lack an icon.
The screenshot cannot identify the exact process behind the grey square; this
fix addresses the duplication mechanism found in the code. Pinned windows are
shown only on their reported desktop, not duplicated based on an empty GUID.

## Upgrade and start

1. Right-click your running old pager and choose **Exit**.
2. Extract this entire ZIP into a new folder. Keep the **native** subfolder.
3. Double-click **BioPager.exe** or **Start.cmd**.

This version includes a compiled Windows x64 EXE. No installation, Python,
Visual Studio, administrator rights, or internet connection is needed. Windows
must have .NET Framework 4.8, as standard on current Windows 10/11 systems.
Your previous bar position and size are retained automatically. On first launch,
BioPager reads existing VernStylePager settings if its own settings file does not
yet exist; subsequent saves use BioPager settings.

**Direct switching and app dragging support Windows 11 24H2 build 26100.2605 or later within 26100,
and Windows 11 25H2 build 26200.** On other builds, use Windows Task View for switching and moving. This release
does not call the version-sensitive native API on unsupported builds and does
not silently fall back to animated keyboard switching. Check your version with Win+R > `winver`.

## Move apps between desktops

1. Press and hold the left mouse button on a miniature app/window.
2. Drag it onto another desktop tile. A valid destination gets a cyan outline.
3. Release to move that individual window to the destination desktop.

You stay on the desktop you were using; the app moves. Successful moves are
silent: no banner, toast, or confirmation text. The move is checked using Windows'
public desktop-ID API. If Windows refuses it, an error still explains why.

- Release outside the bar, press **Escape**, or right-click to cancel.
- Dropping on the original desktop does nothing.
- Small mouse movements still count as a click, not an accidental drag.
- One dragged miniature moves **one window**, not every window of the process.
- Pinned apps/windows shown on all desktops cannot be sorted this way. Turn off
  their all-desktops option in Windows Task View first.
- Some protected/elevated windows cannot be moved. Use Win+Tab for those.

## Reach apps in crowded desktops

Right-click > **Arrange app icons in a grid (easier to drag)**.

This gives each window its own icon cell, making overlapped windows accessible.
Drag those cells exactly like the window miniatures. Turn the option off to
restore the spatial window-layout view. For many apps, also enlarge the tiles
from the right-click menu. Grid cells shrink as the number of windows grows.

## Hide desktop titles

Right-click and uncheck **Show desktop titles**.

The title line disappears and miniatures use the freed space. Hover still shows
names and app titles. The active desktop keeps its gold outline. The duplicate
number formerly displayed before "Desktop 1" has also been removed. This option
is saved, as are the icon-grid option and dock mode.

## Faster desktop switching

Click a tile to switch directly to that desktop through the native
**SwitchDesktop** path, without using **SwitchDesktopWithAnimation**. The old
Win+Ctrl+Arrow loop and its 100/150 ms step waits are gone; switching from desktop
1 to desktop 8 no longer deliberately visits desktops 2 through 7.

An isolated helper stays ready after startup. COM objects and DLL exports are
reused, rather than starting a new process and loading the DLL for every move.
Rapid clicks retain the newest pending destination. Successful actions update
cached miniatures immediately after Windows confirms them. Desktop highlighting
has a light 60 ms check separate from the 750 ms full window refresh.

No global Windows animation setting is changed. Keyboard shortcuts, Windows
Task View, or third-party desktop tools can still animate. Actual switching
latency depends on Windows and the running apps; no Windows timing benchmark
has been performed here. A native failure reports an error rather than falling
back to a slow animated sequence.

## Integrate inside your top taskbar

Right-click > **Embed inside taskbar (experimental)**.

This creates an actual **child window parented to the primary Windows taskbar**.
It is not a floating window positioned over it, and it is not the separate
appbar strip from 0.2. It attaches to the detected horizontal taskbar whether the
taskbar is at the top or bottom, and its height fits the taskbar. Desktop tiles
compress to the available width.

- Drag the pager's **left grip horizontally** to position it along the taskbar.
- Or right-click > **Taskbar position...** and set the distance from the left edge.
- Uncheck **Show desktop titles** for larger miniatures inside the narrow bar.
- Uncheck embedding to return to floating mode.
- Double-click the tray icon to recover a floating pager if the attached panel
  becomes hard to reach. That also disables embedding.

**Compatibility limit:** this is native child-window attachment, not a supported
Explorer deskband/plugin slot. Explorer does not reserve room for this child,
so it can cover existing app buttons or the notification area. Position it in a
free area using the grip/position setting. Taskbar replacements, XAML rendering,
DPI changes, or Windows updates may obscure/reject the child. The app checks the
parent relationship and falls back if attachment fails. These checks cannot
prove that the child is visually unobscured on your particular shell.

The hidden controller/tray remains available independently of the child. If the
taskbar disappears and its child is destroyed, the controller attempts to create
an attached child again; otherwise it falls back to floating mode. This recovery
path requires testing on Windows. No Explorer injection, taskbar style patch,
registry modification, or taskbar button rearrangement is performed.

Other placement options remain:

- **Dock beside taskbar (reserve screen space):** separate Windows appbar strip,
  now placed beside a detected top or bottom taskbar. Maximized apps respect it.
  This is not the inside-taskbar embedding option.
- **Float beside taskbar:** movable strip outside the taskbar, with no reservation.
- **Place over taskbar (floating overlay):** the old floating overlay option.

Embedding and appbar docking are mutually exclusive. Floating mode can be moved
to another monitor; embedding uses the primary taskbar. Vertical taskbars are not
supported by embedding in this release. The separate Task Manager application
is not modified.

## Other controls

| Action | Result |
| --- | --- |
| Click a tile | Direct switch without the pager's transition animation |
| Double-click an app miniature | Switch to its desktop and request focus |
| Drag the left grip | Move the floating bar, or slide the embedded panel horizontally |
| Right-click strip or tray icon | Options, size, Task View, help, exit |
| Double-click tray icon | Recenter/recover the bar |

Use Windows Task View (Win+Tab) to create, remove, rename, or reorder desktops.
Miniatures are diagrams and icons, not live screenshots. Window information
refreshes approximately every 750 ms; refreshing pauses during a drag so the
source and destination don't shift under the mouse.

## First check on your PC

1. Exit 0.2, extract all files, and run the new EXE.
2. Click between distant desktops. Check that there is no slide transition.
3. Drag a disposable Notepad window between tiles. Confirm it moves silently.
4. Turn on taskbar embedding. With your top taskbar, confirm the panel is inside
   it and the taskbar owns its movement/hiding. Check that it receives clicks.
5. Use its grip or Taskbar position setting to avoid existing taskbar buttons.
6. Turn embedding off. Check that the taskbar is unchanged and the pager floats.
7. Restart the pager to check saved titles, placement, and embedding settings.

The Windows x64 EXE was compiled with C# 5 compatibility and warnings treated as
errors. The real helper-client code passed process-reuse, concurrent-request,
timeout, recovery, and disposal tests against a local fake worker. Compiled x64
interop layouts, native DLL exports/hashes, and ZIP integrity were checked.
**The new features have not been run on Windows here.** In particular, no visual
confirmation of taskbar embedding or Windows switch-latency measurement is claimed.
If anything fails, send a screenshot, exact `winver` build, and the name of the
tool you use to put the Windows taskbar at the top.

## Settings, startup and removal

Settings: `%LOCALAPPDATA%\BioPager\settings.txt`.
Settings from earlier versions are read and extended automatically; no manual changes
are needed. To reset all settings, exit and delete that settings file.

For optional automatic startup, open Win+R > `shell:startup` and add a shortcut
to BioPager.exe. The program does not enable this automatically.

To remove, exit the pager, remove any startup shortcut you added, and delete the
extracted folder. Exit unregisters the dock, destroys only the pager's attached child window, and stops its own helper. Settings may be deleted separately.

## Technical details and source

- Files: Pager.cs, MoveWorker.cs, WorkerClient.cs, VersionInfo.cs. Optional local rebuild: Build.cmd.
- Desktop enumeration/names: read-only Explorer registry values. These can change
  with Windows updates. Direct switching uses the bundled native DLL's nonanimated SwitchDesktop path.
- App moving: bundled **VirtualDesktopAccessor** by Jari Pennanen, MIT licensed,
  release `2024-12-16-windows11`. Its original license is in `native/LICENSE.txt`.
- One persistent helper process owns the native API session. A native fault is
  isolated from the pager. Commands use redirected private standard I/O, are
  serialized, and time out after four seconds. Only the helper is stopped on a
  timeout, never the app being moved. Check the app after an error because a move
  may have completed just before failure. The next request recreates the helper.
- The source HWND, process ID and desktop GUID are checked before moving.
  Native desktop numbering is cross-checked against Explorer's GUID list.
  The resulting GUID is checked after moving; success is never drawn optimistically.
- Only the bundled, SHA-256-matching native DLL is loaded from its exact path
  and verified once per helper session.
  This catches corruption or accidental helper replacement. It is not a code signature.
- The bundle makes no network requests, performs no elevation, and captures no
  screenshots. It does not terminate or restart your applications.
- Windows updates may still break the native moving API. Future build families
  are not automatically enabled. Windows 10 moving is not included in this release.
- An attached child is created in the taskbar's DPI context. Restart after major
  display-scale changes. The taskbar customization you use may affect compatibility.

References:
https://github.com/Ciantic/VirtualDesktopAccessor/releases/tag/2024-12-16-windows11
https://github.com/Ciantic/VirtualDesktopAccessor
https://learn.microsoft.com/en-us/windows/win32/shell/application-desktop-toolbars
https://learn.microsoft.com/en-us/windows/win32/api/shobjidl_core/nn-shobjidl_core-ivirtualdesktopmanager
https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setparent
