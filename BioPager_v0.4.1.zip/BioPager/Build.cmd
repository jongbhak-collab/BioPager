@echo off
setlocal
cd /d "%~dp0"
set "PAGER_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%PAGER_CSC%" (
 echo This build requires 64-bit Windows with .NET Framework.
 pause
 exit /b 1
)
echo Building BioPager 0.4.1. Exit the running pager before rebuilding.
"%PAGER_CSC%" /nologo /target:winexe /platform:x64 /optimize+ /out:BioPager.new.exe /resource:assets\BioPager-logo.jpg,BioPager.Logo.jpg /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll Pager.cs MoveWorker.cs WorkerClient.cs VersionInfo.cs > build.log 2>&1
if errorlevel 1 (
 type build.log
 pause
 exit /b 1
)
move /y BioPager.new.exe BioPager.exe >nul
if errorlevel 1 (
 echo Could not replace the EXE. Exit the running pager, then try again.
 pause
 exit /b 1
)
echo Build complete. Run Start.cmd.
