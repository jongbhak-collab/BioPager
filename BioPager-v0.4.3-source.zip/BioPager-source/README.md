# BioPager 0.4.3

BioPager is a compact Windows virtual-desktop pager created by Jong Bhak,
inspired by Vern by One Guy Coding. Click desktop tiles to switch, double-click
an app to focus it, or drag an app between tiles to move its window.

## Run

Copy BioPager.exe to any folder and run it. No adjacent DLL, logo, launcher, or
native folder is required. Exit an older running copy before starting this one.
The single EXE embeds the native helper, artwork, and license notices.

BioPager requires x64 Windows with .NET Framework. Native desktop operations
support Windows 11 24H2 (26100.2605+) and 25H2 (26200); unsupported builds show
an explanation rather than invoking incompatible native interfaces. Windows
updates can affect these version-sensitive desktop interfaces.

## Changes in 0.4.3

- **Integrate with taskbar** now displays a compact top-level overlay within the
  taskbar area. This avoids the old child-window approach, which could be hidden
  behind Windows 11 taskbar content. The pager follows taskbar bounds and DPI and
  recovers when Explorer recreates the taskbar. It stays visible with auto-hide.
  Use **Taskbar position...** or drag the left grip to choose a clear area; the
  overlay can cover taskbar buttons. The old saved integration setting migrates.
- BioPager stays on top by default in floating, integrated, and docked modes. It
  restores its ordering above ordinary always-on-top apps and the taskbar without
  taking keyboard focus. Fullscreen appbar notifications no longer lower it.
  Windows protected desktops, such as UAC, and exclusive fullscreen surfaces
  are outside normal window ordering.
- On a new user's first run, BioPager creates only the missing desktops needed
  to reach six. Existing desktop layouts with more than six are preserved.
  Users upgrading an existing installation keep their desktop layout. Completed
  setup is remembered separately from visual settings; failed setup can retry
  on the next run. Removing desktops later does not recreate them at startup.
- **New desktop** creates a desktop directly without switching away from the
  current one or synthesizing keyboard shortcuts.
- Right-click a tile and choose **Remove Desktop N (move apps to Desktop M)**.
  Windows transfers its windows to the next desktop and leaves the apps open.
  The last desktop wraps to the first. The final remaining desktop cannot be
  removed. The tray menu removes the current desktop. Pinned apps retain their
  Windows pinned behavior. Stale desktop identities and failures are checked
  before success is reported.

Other controls remain: desktop titles, icon grid, background color, tile size,
floating placement, docking with reserved screen space, tray recovery, and Help.
Settings remain in %LOCALAPPDATA%\BioPager. Integration does not reserve a taskbar
slot; choose **Dock beside taskbar** to reserve a separate strip of screen space.

## Start with Windows

Place BioPager.exe or a shortcut to it in your Windows Startup folder. The EXE
can run directly there with no adjacent files.

## Native helper lifetime

The same absolute EXE path launches an isolated worker. Each worker extracts a
SHA-256-verified DLL into a unique version/hash directory under
%LOCALAPPDATA%\BioPager\NativeRuntime. An exclusive lease protects active workers.
Normal shutdown unloads and removes the payload. A later startup removes abandoned
payloads older than one day. Concurrent workers and different releases do not
share extracted DLLs. The working directory is not used to locate dependencies.

## Build and test

Run Build.cmd using the Windows .NET Framework x64 C# compiler. The source tree
requires assets/BioPager-logo.jpg and native/VirtualDesktopAccessor.dll for
embedding. The compiled EXE does not require them beside it.

Run BuildTests.cmd to compile and run the regression suite. The native integration
tests create two temporary desktops and move only a test window, then remove those
temporary desktops. UI tests use an isolated settings directory. See VALIDATION.txt
for the checks completed on this release and their limits.

## Credits and license

Original BioPager code: BioLicense 1.0; see LICENSE. Created by Jong Bhak.
Inspired by Vern, created by One Guy Coding; no Vern code or assets are included.
The embedded VirtualDesktopAccessor dependency is by Jari Pennanen, release
2024-12-16-windows11, under MIT; see native/LICENSE.txt and THIRD_PARTY_NOTICES.md.

https://github.com/Ciantic/VirtualDesktopAccessor
