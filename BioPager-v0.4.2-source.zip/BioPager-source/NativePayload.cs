using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;

namespace BioPager {
 // Each worker owns a verified, private extraction. The lease protects live workers
 // from cleanup; version/hash names prevent mixing native code across releases.
 internal static class NativePayload {
  internal const string ExpectedHash="8740c572a1c000e3b87ffeb1e4c397eae9af3bd4a2abdc3bcffacab4493f8ff5";
  static string directory;
  static FileStream lease;
  internal static string Extract() {
   string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"BioPager","NativeRuntime");
   Directory.CreateDirectory(root);
   Cleanup(root);
   directory=Path.Combine(root,"v0.4.2-"+ExpectedHash+"-"+Guid.NewGuid().ToString("N"));
   Directory.CreateDirectory(directory);
   try {
    lease=new FileStream(Path.Combine(directory,"lease"),FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None);
    string path=Path.Combine(directory,"VirtualDesktopAccessor.dll");
    using(Stream source=Assembly.GetExecutingAssembly().GetManifestResourceStream("BioPager.VirtualDesktopAccessor.dll")) {
     if(source==null)throw new FileNotFoundException("Embedded native helper is missing.");
     using(FileStream target=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.None))source.CopyTo(target);
    }
    using(SHA256 hash=SHA256.Create())using(FileStream file=File.OpenRead(path)) {
     if(BitConverter.ToString(hash.ComputeHash(file)).Replace("-","").ToLowerInvariant()!=ExpectedHash)
      throw new InvalidDataException("Embedded native helper failed verification.");
    }
    return path;
   } catch {Release();throw;}
  }
  internal static void Release() {
   if(lease!=null){lease.Dispose();lease=null;}
   if(directory!=null){TryDelete(directory);directory=null;}
  }
  static void Cleanup(string root) {
   foreach(string path in Directory.GetDirectories(root,"v*")) {
    try {
     if((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)continue;
     if(Directory.GetLastWriteTimeUtc(path)>DateTime.UtcNow.AddDays(-1))continue;
     // A crashed worker leaves an unlocked lease. Never touch an active worker.
     using(new FileStream(Path.Combine(path,"lease"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None)) {
      File.Delete(Path.Combine(path,"VirtualDesktopAccessor.dll"));
     }
     TryDelete(path);
    } catch(IOException) {} catch(UnauthorizedAccessException) {}
   }
  }
  static void TryDelete(string path) {
   try {
    // Only our two known files; never recursively delete an arbitrary directory.
    File.Delete(Path.Combine(path,"VirtualDesktopAccessor.dll"));
    File.Delete(Path.Combine(path,"lease"));
    Directory.Delete(path,false);
   } catch(IOException) {} catch(UnauthorizedAccessException) {}
  }
 }
}
